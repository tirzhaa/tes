const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./db');

const app = express();
const port = 5000;

app.use(cors());
app.use(bodyParser.json());

// Get all todos
app.get('/todos', (req, res) => {
  db.query('SELECT * FROM todos', (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error retrieving todos');
    }
    res.json(results);
  });
});

// Create a new todo
app.post('/todos', (req, res) => {
  const { title } = req.body;
  db.query('INSERT INTO todos (title) VALUES (?)', [title], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error creating todo');
    }
    res.status(201).json({ id: results.insertId, title });
  });
});

// Update a todo (mark as completed)
app.put('/todos/:id', (req, res) => {
  const { id } = req.params;
  const { completed } = req.body;
  db.query('UPDATE todos SET completed = ? WHERE id = ?', [completed, id], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error updating todo');
    }
    res.send('Todo updated');
  });
});

// Delete a todo
app.delete('/todos/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM todos WHERE id = ?', [id], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error deleting todo');
    }
    res.send('Todo deleted');
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
