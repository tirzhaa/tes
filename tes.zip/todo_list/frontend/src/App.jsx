import { useState, useEffect } from 'react';
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState('');

  // useEffect untuk mengambil data todos dari server saat komponen pertama kali dimuat
  useEffect(() => {
    axios.get('http://localhost:5000/todos')
      .then(response => {
        setTodos(response.data); // Menyimpan data todos dari response API
      })
      .catch(err => console.error('Error fetching todos:', err));
  }, []);

  // Fungsi untuk menambahkan todo baru
  const handleAddTodo = () => {
    if (!newTodo) return; // Jangan tambahkan jika input kosong

    axios.post('http://localhost:5000/todos', { title: newTodo })
      .then(response => {
        setTodos([...todos, response.data]); // Menambahkan todo baru ke daftar
        setNewTodo(''); // Mengosongkan input setelah menambah todo
      })
      .catch(err => console.error('Error adding todo:', err));
  };

  // Fungsi untuk mengubah status "selesai" atau "belum selesai"
  const handleToggleCompletion = (id, completed) => {
    axios.put(`http://localhost:5000/todos/${id}`, { completed: !completed })
      .then(() => {
        setTodos(todos.map(todo => 
          todo.id === id ? { ...todo, completed: !completed } : todo
        ));
      })
      .catch(err => console.error('Error toggling completion:', err));
  };

  // Fungsi untuk menghapus todo dengan konfirmasi
  const handleDeleteTodo = (id) => {
    if (window.confirm('Apakah Anda yakin ingin menghapus task ini?')) { // Konfirmasi sebelum menghapus
      axios.delete(`http://localhost:5000/todos/${id}`)
        .then(() => {
          setTodos(todos.filter(todo => todo.id !== id)); // Menghapus todo dari daftar
        })
        .catch(err => console.error('Error deleting todo:', err));
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
      <div className="card shadow-lg" style={{ width: '800px' }}>
        <div className="card-body">
          {/* Title */}
          <h1 className="text-center mb-4">To-Do List</h1>

          {/* Form input untuk menambah todo baru */}
          <div className="mb-3">
            <input 
              type="text" 
              className="form-control"
              placeholder="Tambah task baru..."
              value={newTodo} 
              onChange={(e) => setNewTodo(e.target.value)} 
            />
            <button className="btn btn-primary mt-2 w-100" onClick={handleAddTodo}>Tambah Task</button>
          </div>

          {/* Daftar todos */}
          <ul className="list-group list-group-flush">
            {todos.map((todo, index) => (
              <li key={todo.id} className="list-group-item d-flex justify-content-between align-items-center">
                
                {/* Menampilkan nomor urut di sisi kiri */}
                <span className="text-black mr-5">
                  {index + 1}.
                </span>

                <span 
                  style={{ 
                    textDecoration: todo.completed ? 'line-through' : 'none',
                    color: todo.completed ? 'green' : 'black' // Warna hijau jika sudah selesai
                  }} 
                  onClick={() => handleToggleCompletion(todo.id, todo.completed)}
                  className="cursor-pointer text-truncate w-75"
                >
                  {todo.title}
                </span>

                {/* Status Button */}
                <button 
                  className={`btn btn-sm ${todo.completed ? 'btn-success' : 'btn-warning'} ml-2`} 
                  disabled
                >
                  {todo.completed ? 'Sudah' : 'Belum'}
                </button>
                
                {/* Tombol untuk menghapus todo */}
                <button 
                  className="btn btn-danger btn-sm ml-2"
                  onClick={() => handleDeleteTodo(todo.id)}
                >
                  Hapus
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;
